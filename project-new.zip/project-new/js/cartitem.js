let cartPdts = [];


if (localStorage.getItem('pdts') != null) {
    cartPdts = JSON.parse(localStorage.getItem('pdts'));
    countCart(cartPdts);
  }

console.log(cartPdts);



(function addPdts(){
    let table = '';

    for (const iterator of cartPdts) {
        table +=`<tr>
        //     <td class="text-center">
        //       <img src='${iterator.image}' class="w-25" alt="">
        //     </td>
        //     <td class="text-center">
        //       <div class="product-title">
        //           <p>${iterator.category}</p>
        //       </div>
        //     </td>
        //     <td class="text-center">10</td>
        //     <td class="text-center">
        //         <div class="input-group btn-block">
        //             <input type="text" name="quantity[13]" value="2" size="1" class="form-control form-input">
        //             <span class="input-group-btn">
        //                 <button type="submit" data-toggle="ttvtooltip" title="" class="btn btn-primary rounded-0" data-original-title="Update">
        //                     <i class="fa fa-refresh"></i>
        //                 </button>
        //                 <button type="button" data-toggle="ttvtooltip" title="" class="btn btn-danger rounded-0">
        //                     <i class="fa fa-times-circle"></i>
        //                 </button>
        //             </span>
        //         </div>
        //     </td>
        //     <td class="text-center">${iterator.price}</td>
        //     <td class="text-center">$300.00</td>
        // </tr>`
    }

    document.getElementById('tableContent').innerHTML = table;
})();


function countCart(array) {
    document.getElementById('counter').innerText = array.length;
  }
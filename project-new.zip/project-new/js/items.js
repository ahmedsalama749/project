let cartProduct = [];

if (localStorage.getItem('pdts') != null) {
  cartProduct = JSON.parse(localStorage.getItem('pdts'));
  countCart(cartProduct);
}


async function showProduct() {
  let response = await fetch('https://fakestoreapi.com/products?limit=6');
  let data = await response.json();



  // console.log(data);
  // console.log(productList);

  let productsInfo = '';
  for (let iterator of data) {

    
    productsInfo += `<div class="card mb-3 rounded-4" style="max-width: 540px; max-height: 400px;"> 
        <div class="row g-0">
          <div class=" col-sm-12 col-md-4 ">
          <img src="${iterator.image}" class="img-fluid rounded-start" alt="..." id="image">

          </div>
          <div class=" col-md-8">
            <div class="card-body">
              <h5 class="card-title display-5" id="category">${iterator.category} </h5>
              <p class="card-text lead text-black-50">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <p class="card-text lead fw-bold">Price : <span class="fs-2" id="price">${iterator.price}</span> </p>
              <div>
              <button data-id="${iterator.id}" onclick="${storeData()}" class="btn btn-success bt1 add-cart">Add Cart</button>
              <button id="deleteCart" class="btn btn-success bt1">Delete Cart</button>
                </div>
            </div>
          </div>
        </div>
      </div>`
  }
  document.getElementById('root').innerHTML = productsInfo;
  function storeData(){
    let cartProduct = [];
        for (const iterator of data) {
          cartProduct.push(iterator)
      localStorage.setItem('pdts',JSON.stringify(cartProduct))
    }
  }
};


// function cartBtnHandeler(item) {
//   let cartBtn = document.querySelectorAll(".add-cart");
  
//   for (const element of cartBtn) {
//     element.addEventListener('click', (e) => {
//       let productData = e.target.dataset;
//       if (cartProduct.includes(productData) == false) {
//         cartProduct.push(productData);
//       }
//       localStorage.setItem('pdts', JSON.stringify(cartProduct));
//       countCart(cartProduct);
//     })
//   }

// };


function countCart(array) {
  document.getElementById('counter').innerText = array.length;
}




(async function(){

  await showProduct();
  cartBtnHandeler();
})();
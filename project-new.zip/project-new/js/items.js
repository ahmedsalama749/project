let uesrLogin = document.getElementById("checkUser")
let addCart = document.querySelector('#addCart')
let deleteCart = document.querySelector("#deleteCart")
let card = document.querySelector("#cardShop")
let productName = document.getElementById("root");



async function info() {
  let response = await fetch('https://fakestoreapi.com/products?limit=6');
  let data = await response.json();
  console.log(data);
  let productsInfo = '';
  for (let iterator of data) {
    productsInfo += `<div class="card mb-3 rounded-4" style="max-width: 540px; max-height: 400px;"> 
        <div class="row g-0">
          <div class=" col-sm-12 col-md-4 ">
          <img src="${iterator.image}" class="img-fluid rounded-start" alt="..." id="image">

          </div>
          <div class=" col-md-8">
            <div class="card-body">
              <h5 class="card-title display-5" id="category">${iterator.category} </h5>
              <p class="card-text lead text-black-50">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <p class="card-text lead fw-bold">Price : <span class="fs-2" id="price">${iterator.price}</span> </p>
              <div>
              <button id="addCart"  class="btn btn-success bt1">Add Cart</button>
              <button id="deleteCart" class="btn btn-success bt1">Delete Cart</button>
                </div>
            </div>
          </div>
        </div>
      </div>`
  }
  document.getElementById('root').innerHTML = productsInfo;
  document.getElementById("addCart").addEventListener("click",show);
};

info();


async function show() {
  let responseTwo = await fetch('https://fakestoreapi.com/products?limit=6');
  let result = await responseTwo.json();
  console.log(result);
  let tableInfo = '';
  for (let list of result) {
    tableInfo += `<tr>
    <td class="text-center">
      <img src="${list.image}" alt="">
    </td>
    <td class="text-center">
      <div class="product-title">
          <p>${list.category}</p>
      </div>
    </td>
    <td class="text-center">10</td>
    <td class="text-center">
        <div class="input-group btn-block">
            <input type="text" name="quantity[13]" value="2" size="1" class="form-control form-input">
            <span class="input-group-btn">
                <button type="submit" data-toggle="ttvtooltip" title="" class="btn btn-primary rounded-0" data-original-title="Update">
                    <i class="fa fa-refresh"></i>
                </button>
                <button type="button" data-toggle="ttvtooltip" title="" class="btn btn-danger rounded-0">
                    <i class="fa fa-times-circle"></i>
                </button>
            </span>
        </div>
    </td>
    <td class="text-center">${list.price}</td>
    <td class="text-center">$300.00</td>
</tr>`
  }
  document.getElementById('tableContent').innerHTML = tableInfo;
};



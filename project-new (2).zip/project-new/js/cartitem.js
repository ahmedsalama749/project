let cartPdts = [];
 bt1 = document.querySelectorAll("bt1")

if (localStorage.getItem('pdts') != null) {
    cartPdts = JSON.parse(localStorage.getItem('pdts'));
    countCart(cartPdts);
  }

console.log(cartPdts);



(function addPdts(){
    let table = '';

    for (const iterator of cartPdts) {
        table +=`<tr class="text-center">
        <td >${iterator.id}</td>
        <td>${iterator.title}</td>
        <td>${iterator.category}</td>
        <td>${iterator.price}</td>
        <td><button class="btn text-light bt1" type="button">Update</button></td>
        <td><button onclick="deleteProduct(${iterator.id})" class="btn text-light bt1" type="button">Delete</button></td>
    </tr>`
    }

    document.getElementById('tableContent').innerHTML = table;
})();

  function deleteProduct(id) {
   cartPdts.splice(iterator,title)
   displayProduct(cartPdts)
  }
function countCart(array) {
    document.getElementById('counter').innerText = array.length;
  }
